# Psychemay Cordon - GitHub Resume

Create a free GitHub account for Psychemay, then create a PUBLIC repository named:

YOUR-USERNAME.github.io

Upload `index.html` to the root of the repository.

Then go to:
Settings > Pages > Build and deployment

Choose:
- Source: Deploy from a branch
- Branch: main
- Folder: /(root)

The public resume will be:
https://YOUR-USERNAME.github.io/
